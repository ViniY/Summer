/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pso;

/**
 *
 * @author xuebing
 */
public abstract class Topology {

    public abstract void share(Swarm s);

}

package ec.app.tutorial5;
import ec.app.tutorial4.Task;
import ec.app.tutorial4.VirtualMachine;

import java.io.IOException;
import java.util.ArrayList;

public class PSO {














    class Particle{
        private double[] Solution;

        public Particle(ArrayList<Task> taskList, ArrayList<VirtualMachine> ls_vms, int j){
            this.Solution = new double[taskList.size()];
        }



    }
}
